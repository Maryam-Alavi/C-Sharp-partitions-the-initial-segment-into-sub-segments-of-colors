﻿using Segmentation.Logic;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Segmentation
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome");
            Console.WriteLine("Please press any button to select input file...");
            Console.ReadKey();
            var filePath = SelectFile();
            Console.WriteLine("File loaded successfuly");
            var filelines = ReadFile(filePath);
            var rawSubSegments = SubSegment.OrderSubSegments(filelines);
            Segment segment = new Segment(rawSubSegments);
            var result = segment.GetResult();
            Console.WriteLine("\n***** Result *****\n");
            foreach (var item in result)
            {
                Console.WriteLine(item.Display);
            }
            Console.WriteLine("\n***** End *****\n");

            Console.ReadKey();
        }
        static string SelectFile()
        {
            var dialog = new OpenFileDialog
            {
                Multiselect = false,
                Title = "Open Text File",
                Filter = "Text Document|*.txt;"
            };
            using (dialog)
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    return dialog.FileName;
                }
                else
                {
                    return SelectFile();
                }
            }
        }
        static string[] ReadFile(string path)
        {
            return File.ReadAllLines(path);
        }
    }
}
