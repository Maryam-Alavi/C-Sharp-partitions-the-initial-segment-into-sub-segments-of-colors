﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Segmentation.Logic
{
    public class SubSegment
    {
        public int Start { get; set; }
        public int End { get; set; }
        public string Color { get; set; }
        public string Display { get; set; }
        public static List<SubSegment> OrderSubSegments(string[] lines)
        {
            var result = new List<SubSegment>();
            foreach (var item in lines)
            {
                 var splitItem = item.Trim('[', ']')
                     //split by ; to get color 
                     .Split(';');
                var numbers = splitItem[0].Split('-');
                result.Add(new SubSegment
                {
                    Color = splitItem[1],
                    Start = int.Parse(numbers[0]),
                    End = int.Parse(numbers[1]),
                });
            }
            return result.OrderBy(s => s.Start).ToList();
        }
    }
}
