﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Segmentation.Logic
{
    public class Segment
    {

         public List<SubSegment> Input { get; }
        public List<SubSegment> Result { get; private set; } = new List<SubSegment>() { };
        public string WhiteColor { get; } = "White";

        public Segment(List<SubSegment> input)
        {
            Input = input;
        }

        public List<SubSegment> GetResult()
        {
            if (Input.Count == 0)
            {
                AddSubSegment(int.MinValue, int.MaxValue, WhiteColor, $"[int.MinValue-int.MaxValue]");
                return Result;
            }

            for (int i = 0; i < Input.Count; i++)
            {
                var item = Input[i];
                //[1-100]
                //[20-30]
                //[200-300]
                 
                SubSegment sub = null;
                // 
                if (Result.Any(s => s.Start == item.Start))
                {
                    continue;
                }
                //
                if (Input.Any(s => s.Start > item.Start && s.Start < item.End))
                {
                    var subList = Input.Where(s => s.Start > item.Start && s.Start < item.End).ToList();
                    if (subList.Count > 1)
                    {
                        throw new Exception("More than one subsegment found.");
                    }
                    sub = subList.First();

                }

                if (Result.Count == 0)
                {
                    AddSubSegment(int.MinValue, item.Start - 1, WhiteColor, $"[int.MinValue-{item.Start - 1};{WhiteColor}]");
                }
                if (Result.LastOrDefault().End + 1 != item.Start)
                {
                    AddSubSegment(Result.LastOrDefault().End + 1, item.Start - 1, WhiteColor);
                }
                if (sub != null)
                {
                    AddSubSegment(item.Start, sub.Start - 1, item.Color);
                    AddSubSegment(sub.Start, sub.End, sub.Color);
                    AddSubSegment(sub.End + 1, item.End, item.Color);
                }
                else
                {
                    AddSubSegment(item.Start, item.End, item.Color);
                }

            }
            var maxEnd = Input.Max(s => s.End);
            AddSubSegment(maxEnd + 1, int.MaxValue, WhiteColor, $"[{maxEnd + 1}-int.MaxValue;{WhiteColor}]");
            return Result;
        }
        public List<SubSegment> AddSubSegment(int start, int end, string color, string display = null)
        {
             
            Result.Add(new SubSegment()
            {
                Start = start,
                End = end,
                Color = color,
                Display = display != null ? display : $"[{start}-{end};{color}]"
            });
            return Result;
        }
         
    }
}
